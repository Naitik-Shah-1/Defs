from .dbs import *
from .encryption import *
from .formatting import *
from .login import *
from .math import *
from .time_props import *
from .unc import *


# Number Parser: It doesn't throw errors if 1Million or anything like it is given as an input
# Todo: Create and integrate number parser
# Todo: Test the module Thoroughly
# Todo: Add some more commonly used Defs
# Todo: Rewrite the codebase in c or c++
